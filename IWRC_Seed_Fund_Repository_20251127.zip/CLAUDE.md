# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

IWRC (Illinois Water Resources Center) Seed Fund Tracking & Analysis System - A comprehensive data analysis platform tracking research funding, student outcomes, and project impact from fiscal years 2016-2024.

**Key Metrics (2015-2024):**
- 77 unique projects analyzed
- $8.5M total investment (10-year), $7.3M (5-year)
- 304 students trained
- 14 Illinois institutions funded
- 3% overall ROI

## Repository Structure (Post-November 2025 Reorganization)

The repository was reorganized on November 27, 2025 for improved clarity. Key directories:

```
seed-fund-tracking/
├── deliverables/          # All final outputs (reports + visualizations)
│   ├── reports/           # 6 PDFs (executive + detailed)
│   └── visualizations/    # 36 PNGs + 15 HTML dashboards
├── analysis/              # All code (notebooks + scripts)
│   ├── notebooks/         # 7 Jupyter notebooks
│   └── scripts/           # 44 Python scripts
├── data/                  # Source + consolidated + outputs
│   ├── source/            # Original FY reports (NEVER MODIFY)
│   ├── consolidated/      # Main tracking database
│   └── outputs/           # Analysis results
├── assets/                # Branding and design
│   ├── branding/          # Logos, fonts, guidelines
│   └── styles/            # Shared CSS theme
└── docs/                  # Documentation (22 files)
```

**Navigation:** Start with `index.html` - the main IWRC-branded navigation hub.

## Data Architecture

### Primary Data File
**`data/consolidated/IWRC Seed Fund Tracking.xlsx`** (Main working dataset)
- 539 total project entries (FY2016-2024)
- 35 columns with comprehensive project metrics
- Single "Project Overview" sheet
- Automatic backup created before modifications

### Source Files (data/source/)
- `FY24_reporting_IL.xlsx` - Most recent (FY2024)
- `FY23_reporting_IL.xlsx` - FY2023
- `IWRC-2022-WRRA-Annual-Report-v.101923.xlsx` - FY2022
- `IL_5yr_FY16_20_2.xlsx` - FY2016-2020 aggregate

**Critical:** Source files use multi-level headers (3 rows) with merged cells. Read with `header=[0,1,2]`.

### Key Data Columns
- **Project:** ID, Title, Award Type (104g/104b/Coordination)
- **Personnel:** PI Name, Institution, Department
- **Funding:** Award Amount, Matching Funds, Follow-on Funding
- **Students:** PhD, MS, Undergraduate, Post-Doc (WRRA $ and Matching $)
- **Research:** Science Priorities, Keywords, Methodologies
- **Outputs:** Publications, Presentations, Awards

## Analysis Notebooks (analysis/notebooks/)

Notebooks are numbered for execution order:

1. **`01_comprehensive_roi_analysis.ipynb`** - Complete ROI calculations (10-year tracking)
2. **`02_roi_visualizations.ipynb`** - Investment/ROI charts, Excel summaries
3. **`03_interactive_html_visualizations.ipynb`** - Plotly dashboards and maps
4. **`04_fact_sheet_static_charts.ipynb`** - High-res (300 DPI) PNG charts
5. **`05_project_type_breakdown.ipynb`** - Project composition analysis
6. **`06_interactive_breakdown.ipynb`** - Interactive project type dashboards
7. **`07_award_type_analysis.ipynb`** - Award type deep dive (104b vs All)

**Archive folder:** Contains historical executed notebooks - reference only.

## Common Commands

### Data Analysis
```bash
# Launch Jupyter for interactive analysis
jupyter notebook analysis/notebooks/

# Execute all notebooks in sequence
python analysis/scripts/execute_notebooks.py

# Run a single notebook programmatically
python analysis/scripts/execute_notebook.py analysis/notebooks/01_comprehensive_roi_analysis.ipynb
```

### Data Consolidation (Add New FY Data)
```bash
# 1. Add new Excel file to data/source/
# 2. Run consolidation script
python analysis/scripts/combine_excel_files_v2.py
```

This script:
- Reads multi-level headers with fuzzy column matching
- Appends to consolidated dataset (preserves exact values)
- Creates automatic backup before modifications
- NO data cleaning - preserves source data exactly

### Deliverable Generation
```bash
# Generate all final deliverables (reports + visualizations)
python analysis/scripts/generate_final_deliverables_v2.py

# Generate static PNG visualizations only
python analysis/scripts/generate_static_visualizations.py

# Generate interactive HTML dashboards
python analysis/scripts/generate_interactive_visualizations.py

# Generate PDF reports
python analysis/scripts/generate_pdf_reports.py
```

### Visualization Conversion
```bash
# Convert HTML dashboards to PDF
python analysis/scripts/convert_html_to_pdf.py

# Convert interactive to static images
python analysis/scripts/convert_interactive_to_static.py
```

## IWRC Branding System

All visualizations use centralized IWRC branding via `analysis/scripts/iwrc_brand_style.py`.

### Brand Colors
```python
from iwrc_brand_style import IWRC_COLORS

# Primary palette
IWRC_COLORS['primary']    # #258372 (Teal) - Main brand
IWRC_COLORS['secondary']  # #639757 (Olive) - Secondary
IWRC_COLORS['text']       # #54595F (Gray) - Body text
IWRC_COLORS['accent']     # #FCC080 (Peach) - Highlights
```

### Typography
- **Font Family:** Montserrat (Regular, Bold)
- **Headlines:** Montserrat Semibold
- **Body Text:** Montserrat Light
- **Font files:** Located in `assets/branding/fonts/`

### Applying Branding to Charts
```python
from iwrc_brand_style import (
    configure_matplotlib_iwrc,
    apply_iwrc_matplotlib_style,
    apply_iwrc_plotly_style
)

# For matplotlib
configure_matplotlib_iwrc()
fig, ax = plt.subplots()
# ... create chart ...
apply_iwrc_matplotlib_style(fig, ax)

# For Plotly
fig = go.Figure()
# ... create chart ...
apply_iwrc_plotly_style(fig)
```

### Branding Assets
- **Logos:** `assets/branding/logos/` (PNG and SVG)
- **Guidelines:** `assets/branding/IWRC_BRANDING_GUIDELINES.md`
- **CSS Theme:** `assets/styles/iwrc-theme.css`

## Key Implementation Details

### Award Type Analysis (Dual-Track)
The analysis supports two project tracks:
- **104B Only:** Base grants (seed funding efficiency)
- **All Projects:** Complete program (104g + 104b + Coordination)

Generate comparisons with:
```bash
python analysis/scripts/generate_dual_track_deliverables.py
```

### Project Year Extraction
Project years are extracted from Project ID using regex:
```python
# Pattern: Matches 4-digit years (2015-2024) or FY## format
year_match = re.search(r'(20\d{2}|19\d{2})', project_id_str)
fy_match = re.search(r'FY(\d{2})', project_id_str, re.IGNORECASE)
```

### Time Periods
- **10-year:** 2015-2024 (most common for deliverables)
- **5-year:** 2020-2024 (recent trends)
- **Full dataset:** FY2016-2024 (539 projects)

### Data Integrity Rules
**CRITICAL - NEVER violate these:**
- NEVER modify data in `data/source/` files
- NEVER clean or alter values during consolidation
- Preserve exact values from source (including inconsistent formats)
- Always create backups before modifying consolidated data
- Maintain NaN values as-is

## Deliverables Structure

### Reports (deliverables/reports/)
**Executive (3 PDFs):**
- `executive_summary.pdf` - Program overview with key metrics
- `fact_sheet.pdf` - One-page impact snapshot
- `financial_summary.pdf` - Financial metrics and ROI

**Detailed (3 PDFs):**
- `detailed_analysis_report.pdf` - Comprehensive analysis with charts
- `project_type_analysis_104b_only.pdf` - Base grants breakdown
- `project_type_analysis_all_projects.pdf` - Complete breakdown

### Visualizations (deliverables/visualizations/)
**Static (36 PNGs at 300 DPI):**
- `overview/` (4): Investment, ROI, trends
- `institutions/` (4): Reach, funding distribution
- `students/` (3): Training outcomes
- `topics/` (7): Research area analysis
- `awards/` (10): Award type comparisons
- `project_types/` (8): Type breakdowns (104b + All)

**Interactive (15 HTML dashboards):**
- `core/` (5): ROI, detailed analysis, investment, students, timeline
- `geographic/` (2): Illinois institutions maps
- `award_types/` (3): Award analysis dashboards
- `project_types/` (4): Interactive breakdowns

## Dependencies

**Python 3.8+ required**

```bash
# Core data analysis
pip install pandas openpyxl numpy

# Visualization
pip install matplotlib seaborn plotly

# Map generation
pip install folium

# PDF generation
pip install reportlab
```

Complete installation:
```bash
pip install pandas numpy matplotlib plotly openpyxl reportlab folium seaborn
```

## Key Workflows

### Workflow 1: Add New Fiscal Year Data
1. Place new Excel file in `data/source/`
2. Run: `python analysis/scripts/combine_excel_files_v2.py`
3. Verify consolidated data updated correctly
4. Re-run notebooks: `python analysis/scripts/execute_notebooks.py`
5. Regenerate deliverables: `python analysis/scripts/generate_final_deliverables_v2.py`

### Workflow 2: Update Visualizations
1. Modify notebook in `analysis/notebooks/`
2. Execute notebook to test
3. Run generation script to create deliverable versions
4. Outputs saved to `deliverables/visualizations/`

### Workflow 3: Create New Analysis
1. Create new notebook in `analysis/notebooks/`
2. Load data from: `data/consolidated/IWRC Seed Fund Tracking.xlsx`
3. Use IWRC branding: `from iwrc_brand_style import *`
4. Save outputs to appropriate `deliverables/` subfolder
5. Update documentation as needed

## Documentation

**Core Documentation (docs/):**
- `METHODOLOGY.md` - Analysis approach and calculations
- `DATA_DICTIONARY.md` - Column definitions and data structure
- `FINDINGS.md` - Research findings and insights
- `REPOSITORY_SUMMARY.md` - Detailed repository overview
- `REORGANIZATION_NOVEMBER_2025.md` - November reorganization details

**Guides:**
- `AWARD_TYPE_ANALYSIS_GUIDE.md` - Award types explained (104g, 104b, Coordination)
- `FINAL_DELIVERABLES_GUIDE.md` - Deliverables structure and contents
- `EXPORT_TO_PDF_GUIDE.md` - PDF export instructions

## Navigation and User Interface

**Main entry point:** `index.html` - IWRC-branded navigation hub
**Deliverables hub:** `deliverables/index.html` - Browse all outputs

Features:
- Card-based navigation
- Breadcrumb trails
- Responsive design
- Professional IWRC branding throughout

## Path References

**Absolute paths used in scripts:** Most scripts use absolute paths to `/Users/shivpat/seed-fund-tracking/`. When running scripts from different locations or adapting for other environments, update these paths.

**Logo paths in branding module:**
```python
LOGO_PATH = '/Users/shivpat/seed-fund-tracking/IWRC Logo - Full Color.svg'
LOGO_PNG_PATH = '/Users/shivpat/seed-fund-tracking/IWRC_Logo.png'
```

## Archive Management

- **Code archives:** `analysis/notebooks/archive/` - Historical notebooks
- **Old visualizations:** Archived with timestamp (e.g., `archived_old_visualizations_2025-11-22/`)
- **Backups:** Auto-generated for data files before modification

## Version Control

The `.gitignore` is configured to exclude:
- Python bytecode (`__pycache__/`)
- Virtual environments (`.venv/`, `venv/`)
- Jupyter checkpoints (`.ipynb_checkpoints/`)
- IDE files (`.vscode/`, `.idea/`)
- This file (`CLAUDE.md`)

Large files (Excel, PNG, PDF) ARE tracked in git for this project.
